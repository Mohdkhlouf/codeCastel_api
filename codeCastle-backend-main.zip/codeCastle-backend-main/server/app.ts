import express from "express";
import cors from "cors";
import "dotenv/config";

import { loggingMiddleware } from "./middlewares/logging";
import { apiErrorHandler } from "./middlewares/apiErrorHandler";
import { routeNotFound } from "./middlewares/routeNotFound";
import storiesRouter from "./routes/storiesRoute";

const app = express();
app.use(cors());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/v1/stories", loggingMiddleware, storiesRouter);

app.use(apiErrorHandler);
app.use(routeNotFound);

export default app