import { z } from "zod";
import mongoose from "mongoose";

import { categoryBodySchema } from "../schemas/categorySchema";

export type Story = z.infer<typeof categoryBodySchema> & {
    _id: mongoose.Types.ObjectId;
};
export type CreateCategoryInput = z.infer<typeof categoryBodySchema>;
export type UpdateCategoryInput = Partial<Story>;
