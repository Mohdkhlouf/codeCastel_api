import { z } from "zod";

import { storyBodySchema } from "../schemas/stroySchema";
import mongoose from "mongoose";

export type Story = z.infer<typeof storyBodySchema> & {
    _id: mongoose.Types.ObjectId;
};
export type CreateStoryInput = z.infer<typeof storyBodySchema>;
export type UpdateStoryInput = Partial<Story>;
