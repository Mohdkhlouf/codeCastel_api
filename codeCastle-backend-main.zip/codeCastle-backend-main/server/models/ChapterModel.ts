import mongoose from "mongoose";

const Schema = mongoose.Schema;

const ChapterSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    content: {
        type: String,
        required: true,
    },
    chapterAnimation: {
        type: String,
        required: true,
    },
    storyId: {
        type: Schema.Types.ObjectId,
        ref: "Story",
        required: true,
    },
    createdAt: {
        type: Date,
        required: true,
    },
    updatedAt: {
        type: Date,
        required: true,
    },
});

export default mongoose.model("Chapter", ChapterSchema);