import mongoose from "mongoose";

const Schema = mongoose.Schema;

const StorySchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    chapters: [
    {
        content: {
            type: String,
            required: true,
        },
        image: {
            type: String,
            required: false,
        },
    }],
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

export default mongoose.model("Story", StorySchema);