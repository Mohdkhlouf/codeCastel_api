import express from "express";

import storiesController from "../controllers/stories";

const storiesRouter = express.Router();

storiesRouter.get("/", storiesController.getAllStories);
storiesRouter.get("/:id", storiesController.getSingleStory);
storiesRouter.post("/", storiesController.createStory);
storiesRouter.delete("/:id", storiesController.deleteStory);

export default storiesRouter;