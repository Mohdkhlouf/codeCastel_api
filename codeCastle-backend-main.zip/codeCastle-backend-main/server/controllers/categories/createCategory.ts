import { NextFunction, Request, Response } from "express";

import categoriesService from "../../services/categoriesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const createCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
    ) => {
    const newCategory = req.body;
    const category = await categoriesService.createOne(newCategory);
    if (!category) {
        next(ApiError.resourceNotFound("Could create category. Please try again."));
        return;
    }
    res.status(201).json({
        message: "Category successfully created",
        category
    });
};
