import { NextFunction, Request, Response } from "express";

import categoriesService from "../../services/categoriesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const updateCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
    ) => {
    const id = req.params.categoryId;
    const updatedCategory = req.body;
    const category = await categoriesService.updateCategory(id, updatedCategory);
    if (category === null) {
        next(ApiError.resourceNotFound("Category id is not found"));
        return;
    }
    res.status(200).json({ message: "Category updated successfully" });
};
