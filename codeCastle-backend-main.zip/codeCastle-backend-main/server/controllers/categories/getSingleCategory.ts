import { NextFunction, Request, Response } from "express";

import { ApiError } from "../../middlewares/errors/ApiError";
import categoriesService from "../../services/categoriesService";

export const getSingleCatgory = async (req: Request, res: Response, next: NextFunction) => {
    const id = req.params.storyId;
    const catgory = await categoriesService.getSingle(id);
    if (!catgory) {
        next(ApiError.resourceNotFound("Catgory is not found"));
        return;
    }
    res.status(200).json(catgory);
};
