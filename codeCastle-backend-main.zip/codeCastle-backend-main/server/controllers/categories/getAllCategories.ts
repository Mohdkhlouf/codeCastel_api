import { Request, Response, NextFunction } from "express";

import { ApiError } from "../../middlewares/errors/ApiError";
import CategoriesService from "../../services/categoriesService";

export async function getAllCategories(
    _: Request,
    res: Response,
    next: NextFunction
    ) {
    try {
        const categories = await CategoriesService.findAll();
        if (!categories) {
        next(ApiError.resourceNotFound("Categories not found"));
        return;
        }
        if (categories.length <= 0) {
        res.status(200).json({ msg: "No category data yet" });
        return;
        }
        res.status(200).json(categories);
    } catch (error) {
        next(ApiError.resourceNotFound("Categories not found"));
    }
}

