import { getAllCategories } from './getAllCategories';
import { getSingleCatgory } from './getSingleCategory';
// import { createCategory } from './createCategory';
// import { updateCategory } from './updateCategory';
// import { deleteCategory } from './deleteCategory';

export default {
    getAllCategories,
    getSingleCatgory,
    // createCategory,
    // updateCategory,
    // deleteCategory
}