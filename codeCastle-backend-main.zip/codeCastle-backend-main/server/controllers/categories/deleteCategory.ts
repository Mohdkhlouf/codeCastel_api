import { NextFunction, Request, Response } from "express";

import categoriesService from "../../services/categoriesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const deleteCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
    ) => {
    const id = req.params.categoryId;
    const deletedCategory = await categoriesService.deleteCategory(id);
    if (deletedCategory === null) {
        next(ApiError.resourceNotFound("Category id is not found"));
        return;
    }
    res.status(200).json({ message: "Category deleted successfully" });
};
