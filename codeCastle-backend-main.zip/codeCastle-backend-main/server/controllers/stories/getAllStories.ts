import { Request, Response, NextFunction } from "express";

import { ApiError } from "../../middlewares/errors/ApiError";
import StoryService from "../../services/storiesService";

export async function getAllStories(
    _: Request,
    res: Response,
    next: NextFunction
    ) {
    try {
        const stories = await StoryService.findAll();
        if (!stories) {
        next(ApiError.resourceNotFound("Story not found"));
        return;
        }
        if (stories.length <= 0) {
        res.status(200).json({ msg: "No story data yet" });
        return;
        }
        res.status(200).json(stories);
    } catch (error) {
        next(ApiError.resourceNotFound("Stories not found"));
    }
}

