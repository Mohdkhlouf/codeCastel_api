import { NextFunction, Request, Response } from "express";

import storiesService from "../../services/storiesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const createStory = async (
    req: Request,
    res: Response,
    next: NextFunction
    ) => {
    const newStory = req.body;
    const story = await storiesService.createOne(newStory);
    if (!story) {
        next(ApiError.resourceNotFound("Could create story. Please try again."));
        return;
    }
    res.status(201).json({
        message: "Story successfully created",
        story,
    });
};
