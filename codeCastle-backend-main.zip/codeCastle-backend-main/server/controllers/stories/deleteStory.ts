import { NextFunction, Request, Response } from "express";

import storiesService from "../../services/storiesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const deleteStory = async (
    req: Request,
    res: Response,
    next: NextFunction
    ) => {
    const id = req.params.storyId;
    const deletedStory = await storiesService.deleteStory(id);
    if (deletedStory === null) {
        next(ApiError.resourceNotFound("Story id is not found"));
        return;
    }
    res.status(200).json({ message: "Story deleted successfully" });
};
