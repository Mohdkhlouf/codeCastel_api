import { createStory } from "./createStory";
import { getAllStories } from "./getAllStories";
import { getSingleStory } from "./getSingleStory";
import { deleteStory } from "./deleteStory";

export default {
    getAllStories,
    getSingleStory,
    createStory,
    deleteStory
}