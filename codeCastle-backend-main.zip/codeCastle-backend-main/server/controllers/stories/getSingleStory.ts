import { NextFunction, Request, Response } from "express";

import storiesService from "../../services/storiesService";
import { ApiError } from "../../middlewares/errors/ApiError";

export const getSingleStory = async (req: Request, res: Response, next: NextFunction) => {
    const id = req.params.storyId;
    const story = await storiesService.getSingle(id);
    if (!story) {
        next(ApiError.resourceNotFound("Story is not found"));
        return;
    }
    res.status(200).json(story);
};
