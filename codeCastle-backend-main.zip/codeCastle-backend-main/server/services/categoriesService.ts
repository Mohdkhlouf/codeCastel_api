import mongoose from "mongoose";
import CategoryRepo from "../models/CategoryModel";
import { CreateCategoryInput, UpdateCategoryInput } from "../types/Category";

async function findAll() {
    const categories = await CategoryRepo.find().exec();
    return categories;
}

async function getSingle(categoryId: string) {
    const id = new mongoose.Types.ObjectId(categoryId);
    return await CategoryRepo.findOne({ _id: id }).exec();
}

async function createOne(createData: CreateCategoryInput) {
    const newCategory = new CategoryRepo(createData);
    return await newCategory.save();
}

async function updateCategory(categoryId: string, updateData: UpdateCategoryInput) {
    const id = new mongoose.Types.ObjectId(categoryId);
    return await CategoryRepo.findByIdAndUpdate
    (id, updateData, { new: true });
}

async function deleteCategory(categoryId: string) {
    const id = new mongoose.Types.ObjectId(categoryId);
    return await CategoryRepo.findByIdAndDelete(id);
}

export default {
    findAll,
    getSingle,
    createOne,
    updateCategory,
    deleteCategory
}