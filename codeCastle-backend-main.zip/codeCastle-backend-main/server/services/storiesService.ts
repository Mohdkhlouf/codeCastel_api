import mongoose from 'mongoose';
import StoryRepo from '../models/StoryModel';
import { CreateStoryInput, UpdateStoryInput } from '../types/Story';

async function findAll() {
    const users = await StoryRepo.find()
    .exec();
    return users;
}

async function getSingle(categoryId: string) {
    const id = new mongoose.Types.ObjectId(categoryId);
    return await StoryRepo.findOne({ _id: id }).exec();
}

async function createOne(createData: CreateStoryInput) {
    const newStory = new StoryRepo(createData);
    return await newStory.save();
}

async function updateStory(
    storyId: string,
    updateData: UpdateStoryInput
) {
    const id = new mongoose.Types.ObjectId(storyId);
    return await StoryRepo.findByIdAndUpdate(id, updateData, { new: true });
}

async function deleteStory(storyId: string) {
    const id = new mongoose.Types.ObjectId(storyId);
    return await StoryRepo.findByIdAndDelete(id);
}

export default {
    findAll,
    getSingle,
    createOne,
    updateStory,
    deleteStory
}