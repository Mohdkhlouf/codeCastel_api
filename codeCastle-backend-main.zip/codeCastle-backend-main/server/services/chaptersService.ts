import mongoose from 'mongoose';

import ChapterRepo from '../models/ChapterModel';

async function findAll() {
    const chapters = await ChapterRepo.find().exec();
    return chapters;
}

async function getSingle(chapterId: string) {
    const id = new mongoose.Types.ObjectId(chapterId);
    return await ChapterRepo.findOne({ _id: id }).exec();
}

async function createOne(createData: any) {
    const newChapter = new ChapterRepo(createData);
    return await newChapter.save();
}

async function updateChapter(chapterId: string, updateData: any) {
    const id = new mongoose.Types.ObjectId(chapterId);
    return await ChapterRepo.findByIdAndUpdate
    (id, updateData, { new: true });
}

async function deleteChapter(chapterId: string) {
    const id = new mongoose.Types.ObjectId(chapterId);
    return await ChapterRepo.findByIdAndDelete(id);
}

export default {
    findAll,
    getSingle,
    createOne,
    updateChapter,
    deleteChapter
}