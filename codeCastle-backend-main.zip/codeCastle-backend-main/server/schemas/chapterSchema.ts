import mongoose from "mongoose";
import { z } from "zod";

export const chapterBodySchema = z.object({
    title: z.string(),
    content: z.string(),
    chapterAnimation: z.string(),
    storyId: z
        .string()
        .refine((val) => mongoose.Types.ObjectId.isValid(val)),
    createdAt: z.date(),
    updatedAt: z.date(),
});