import { z } from "zod";

export const storyBodySchema = z.object({
    title: z.string(),
    chapters: z.array(z.object({
        content: z.string(),
        image: z.string().optional(),
    })),
    authorId: z.string(),
    categoryId: z.string(),
    createdAt: z.date().optional(),
    updatedAt: z.date().optional(),
});

export const StorySchema = z.object({
    body: storyBodySchema
});