import { z } from "zod";

export const categoryBodySchema = z.object({
    name: z.string(),
    description: z.string(),
    thumbnail: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
});

export const CategorySchema = z.object({
    body: categoryBodySchema
});